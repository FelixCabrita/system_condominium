<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if (!function_exists('checkForPermissions'))
{ 
    function checkForPermissions($Endpoint,$Permission){ 
        $CI =& get_instance();  
        $DoesHavePermission = false; 
      
        switch($Permission){
            case PERMISSION_READ:
                $PermissionValue = $CI->getPermissions()->{$Endpoint}->R; 
                $DoesHavePermission = $PermissionValue === 1;
            break;
            case PERMISSION_CREATE:
                $PermissionValue = $CI->getPermissions()->{$Endpoint}->C;
                $DoesHavePermission = $PermissionValue === 1;
            break;
            case PERMISSION_UPDATE:
                $PermissionValue = $CI->getPermissions()->{$Endpoint}->U;
                $DoesHavePermission = $PermissionValue === 1;
            break;
            case PERMISSION_DELETE:
                $PermissionValue = $CI->getPermissions()->{$Endpoint}->D;
                $DoesHavePermission = $PermissionValue === 1;
            break;
        } 
        return $DoesHavePermission;
    } 
}

if (!function_exists('checkRole'))
{  
    function checkRole($rol){  
        $role_text =$rol;
        switch($rol){
            case ROLE_ADMIN:
                $role_text = "SUPER ADMINISTRADOR";
            break;
            case ROLE_MANAGER:
                $role_text = "ADMINISTRADOR";
            break;
            case ROLE_VENDOR:
                $role_text = "CAJA";
            break;
            case ROLE_ACCOUNTING:
                $role_text = "CONTABILIDAD";
            break;
            case ROLE_VIGILANT:
                $role_text = "VIGILANTE";
            break;
            case ROLE_OWNER:
                $role_text = "PROPIETARIO APTO.";
            break; 
            case ROLE_TENANT:
                $role_text = "INQUILINO APTO.";
            break;
        } 
        return $role_text;
    } 
}

if (!function_exists('getPermission'))
{  
    function getPermission($rol){  
        $permission =PERMISSION_DEFAULT;
        switch($rol){
            case ROLE_ADMIN:
                $permission =PERMISSION_DEFAULT;
            break;
            case ROLE_MANAGER:
                $permission =PERMISSION_DEFAULT;
            break;
            case ROLE_VENDOR:
                $permission =PERMISSION_DEFAULT;
            break;
            case ROLE_ACCOUNTING:
                $permission =PERMISSION_DEFAULT;
            break;
            case ROLE_VIGILANT:
                $permission =PERMISSION_VIGILANT;
            break;
            case ROLE_OWNER:
                $permission =PERMISSION_TENANT;
            break; 
            case ROLE_TENANT:
                $permission =PERMISSION_TENANT;
            break;
        } 
        return $permission;
    } 
}

?>